/* Helper file. Use it only if you want. 
 *
 */
 
#ifndef __GAME_H__
#define __GAME_H__

// Initializes the board with spaces
int init_board();

// Makes a move on the given column
int make_move(int column, char p);

// Shows board on the screen.
int show_board();

// Verify the table to see if there's a winner.
int is_winner();

// Fills in a string with '-', 'r' and 'y'. 'r' corresponds to 'X'. 
void fill_board(char* b);

#endif
