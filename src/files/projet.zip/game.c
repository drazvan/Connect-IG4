/* Helper file. Use it only if you want. 
 *
 */
#include <stdio.h>

#include "game.h"

// The character of the current player
char p_char = ' ';					

// The game board
char board[6][7];

// Initializes the board with spaces.
int init_board()
{
	int i, j;

	for (i = 5; i >= 0; i--)
	{
		for (j = 0; j < 7; j++)
			board[i][j] = ' ';
	}
}

// Makes a move on the given column.
int make_move(int column, char p)
{
	int l = 0;
	
	// decrement column since arrays start at 0
	column--;
	
	while (l < 6 && board[l][column] != ' ')
		l++;
		
	if (l == 6)
	{
		printf("Column is full!\n");
		return -1;
	}
	
	board[l][column] = p;
	
	return 0;
}

// Shows board on the screen.
int show_board()
{
	int i, j;

	printf("---------------\n");
	for (i = 5; i >= 0; i--)
	{
		printf("|");
		for (j = 0; j < 7; j++)
			printf("%c|", board[i][j]);
		printf("\n");
	}
	printf("---------------\n");
	printf("-1-2-3-4-5-6-7-\n");
}

// Verify the table to see if there's a winner.
int is_winner()
{
	int i, j;
	char win = ' ';
	
	// horizontal
	for (i = 0; i < 6; i++)
		for (j = 0; j < 4; j++)
			if (board[i][j] != ' ' && board[i][j] == board[i][j+1] && board[i][j] == board[i][j+2] && board[i][j] == board[i][j+3])
				win = board[i][j];

	// vertical
	for (i = 0; i < 3; i++)
		for (j = 0; j < 7; j++)
			if (board[i][j] != ' ' && board[i][j] == board[i+1][j] && board[i][j] == board[i+2][j] && board[i][j] == board[i+3][j])
				win = board[i][j];	
	
	// diagonal 1
	for (i = 0; i < 3; i++)
		for (j = 0; j < 4; j++)
			if (board[i][j] != ' ' && board[i][j] == board[i+1][j+1] && board[i][j] == board[i+2][j+2] && board[i][j] == board[i+3][j+3])
				win = board[i][j];	
				
	// diagonal 2
	for (i = 3; i < 6; i++)
		for (j = 0; j < 4; j++)
			if (board[i][j] != ' ' && board[i][j] == board[i-1][j+1] && board[i][j] == board[i-2][j+2] && board[i][j] == board[i-3][j+3])
				win = board[i][j];	
		
	if (win != ' ')
	{
		if (win == p_char)
		{
			printf("You WON !!!\n");
		}
		else 
		{
			printf("You lost :( ...\n");
		}
		
		return 1;
	}

	return 0;
}

// Fills in a string with '-', 'r' and 'y'. 'r' corresponds to 'X'. 
void fill_board(char* b)
{
	int i=0, j=0, p=0;

	for (i = 5; i >= 0; i--)
	{
		for (j = 0; j < 7; j++)
		{
			switch(	board[i][j])
			{
				case ' ':
					b[p] = '-';
					break;
				case 'X': 
					b[p] = 'r';
					break;
				case 'O':
					b[p] = 'y';
					break;
			}
			p++;
		}
	}
	
	b[42] = 0;
}
