#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>

#include "game.h"
#include "http.h"

#define max(x, y) (x > y ? x : y)

int game_server_port = 0;			// The port on which we listen for incoming game requests

char opponent_ip[16];				// The opponents ip (when we join)
int opponent_port = 0;				// The opponents port (when we join)

// TODO: (2) define game states here
#define NONE 0
#define FINISHED 100

// Structure with the parameters requiered for API calls
struct param 
{
	// The requested command
	char command[30];

	//
	// TODO: (1) fill in the rest
	//
};

// The structure that will be used throughout the code to send requests
struct param req;

// Creates and connects a socket
int create_socket(int protocol, char* ip, int port)
{
	//
	// TODO: (1) create a socket to 'ip':'port' and return it
	//
	
	return 0;
}

// Sends a request to the public server
char* send_request(struct param params)
{
	int socketfd;				// socket to connectig4.appspot.com:80
	char data[255];				// data part of the request
	char response[1000];		// the whole response from the server
	int bytes_read;				// the length of the response

	//
	// TODO: (1) connect the 'socketfd' socket to connectig4.appspot.com:80
	//
	
	// We compose the data to be sent
	sprintf(data, "command=%s", params.command );
	
	char buffer[1000];
	sprintf(buffer, "POST /api HTTP/1.1\nHost: connectig4.appspot.com\nContent-Type: application/x-www-form-urlencoded\nContent-Length: %d\n\n%s", 
			strlen(data), data);

	//
	// TODO: (1) send request and wait for response			
	//
	
	// Extracts only th epart between --- and ---
	int count = 0, start = 0, end = 0;
	
	// find the begining of the server's message (marked by "---")
	for (; start < bytes_read && count < 3; start++)
	{
		if (response[start] == '-')
			count++;
		else
			count = 0;
	}
	
	end = start + 1;
	count = 0;
	
	for (; end < bytes_read && count < 3; end++)
	{
		if (response[end] == '-')
			count++;
		else
			count = 0;
	}
	
	// truncate the original str to the begining of the last ---
	response[end - 3] = 0;

	char* res = malloc(1000);	
	strcpy(res, response + start + 1);
	
	// everything went ok
	return res;
} 

// Extracts the local ip.
// The best solution is to create a UDP socket to some external ip.
void get_local_ip(char* str_ip)
{
	int sock = create_socket(SOCK_DGRAM, "8.8.8.8", 43);

	struct sockaddr_in name;
    int namelen = sizeof(name);
    getsockname(sock, (struct sockaddr*) &name, &namelen);

    char* p = inet_ntoa(name.sin_addr);
	strcpy(str_ip, p); 
	
    close(sock);
}

// Starts the game server (where the other players will connect)
int start_game_server()
{
	int game_sock = socket(AF_INET, SOCK_STREAM, 0);
	struct sockaddr_in game_addr;
	
	memset(&game_addr, 0, sizeof(game_addr));
	
	//
	// TODO: (1) Listen on any IP address on a random port.
	//
		
	return game_sock;
}

int main(int argc, char** argv)
{
	if (argc < 3)
	{
		printf("Insufficient arguments. Usage %s 'nickname' 'password'.\n", argv[0]);
		return;
	}

	int game_server_sock = start_game_server();			// socket were we listen for new connections from other players

	memset(&req, 0, sizeof(struct param));
	
	sprintf(req.command, "connect");
	
	//
	// TODO: (1) fill in other required parameters for the 'connect' API call
	//
		
	send_request(req);
	

	// file descriptors (stdin, files, sockets, etc.)
	fd_set fds;
	
	printf ("connect4> ");
	fflush(stdout);
	
	int n, retval;
	struct timeval tv;
	
	/* Wait up to five seconds. */
    tv.tv_sec = 5;
    tv.tv_usec = 0;

	char command[200];
	
	while(1)
	{
		FD_ZERO(&fds);
		
		// 
		// TODO: (1) create a set of file descriptors (fds) with standard input, game_server_sock, opponent, HTTP server, etc.
		// 

		// Wait for something to happen or for 5 seconds to pass
		retval = select(game_server_sock + 1, &fds, NULL, NULL, &tv);
		
		// if it's a timeout
		if (retval == 0)
		{
			// 
			// TODO: (1/2) send a ping to the server
			//
			
			tv.tv_sec = 5;
		} else 
		{
			// if we have a new game connection
			if (FD_ISSET(game_server_sock, &fds))
			{
				// 
				// TODO: (2) Here we have a game request form another player
				//
			}
			
			// TODO: (2) Here you should treat messages from the opponent too
			
					
			// if we have input from the user
			if (FD_ISSET(0, &fds))
			{
				fgets(command, 200, stdin);
			
				// list	
				if (strncmp(command, "list", 4) == 0)
				{
					sprintf(req.command, "list");
					char* response = send_request(req);
					printf ("%s\n", response);
					
					free(response);
				} else
				// create
				if (strncmp(command, "create", 6) == 0)
				{
					sprintf(req.command, "create");
					char* response = send_request(req);
					printf ("%s\n", response);
					
					// 
					// TODO: (2) do something with the game id ( atoi(response + 3) )
					//
										
					free(response);
				} else
				// join
				if (strncmp(command, "join", 4) == 0)
				{
					sprintf(req.command, "join");
					
					// get rid of the \n in the command
					command[strlen(command) - 1] = 0;

					//
					// TODO: (2) fill in the opponent
					//
					
					char* response = send_request(req);
					printf ("%s\n", response);

					// extract ip address and port
					char *ip_end = response + 3;
					while (*ip_end != ',')
						ip_end++;
					*ip_end = 0;
					
					strcpy(opponent_ip, response + 3);
					opponent_port = atoi(ip_end + 2);
					
					printf("Opponent IP address is '%s':%d\n", opponent_ip, opponent_port);
					
					//
					// TODO: (2) Connect to the opponent and start the game
					//
										
					free(response);
				} else
				// move
				if (strncmp(command, "move", 4) == 0)
				{		
					int column = atoi(command + 5);
						
					//
					// TODO: (2) do something with the move given by the user
					//
					
				} else
				// exit
				if (strncmp(command, "exit", 4) == 0)
				{
					return 0;
				} else
				// help
				if (strncmp(command, "help", 4) == 0)
				{
					printf("Available commands:\n");
					printf(" - list: shows the list of current waiting games\n");
					printf(" - create: create a new game and wait for players\n");
					printf(" - join 'player': joins the game created by the given player\n");
					printf(" - move 'column': make a game move\n");
					printf(" - help: shows this help\n");
					printf(" - exit\n");
				} else
				{
					printf("unknown command %s\n", command);
				}	
				
				// Show a new prompt
				printf ("connect4> ");
				fflush(stdout);
			}
		}
	}

	return 0;
}
